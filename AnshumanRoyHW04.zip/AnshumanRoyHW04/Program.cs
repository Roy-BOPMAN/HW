﻿using System;

//Anshuman Roy
//IGME 105
//10/26/2021
//HW04 - Gradebook

namespace AnshumanRoyHW04
{
    class Program
    {
        static void Main(string[] args)
        {

            //-----------------------------------------
            //  PSEUDOCODE - PART 1
            //-----------------------------------------
            /* Variables: 
             * The total number of possible grades
             * The set of assignment names
             * The set of assignment grade
             */
            Console.WriteLine("Welcome to the Gradebook!");
            Console.Write("\nHow many assignments have you had?\t\t\t");
            int numbOfGrades = int.Parse(Console.ReadLine());

            while (numbOfGrades < 0)
            {
                Console.Write("Not a valid whole number. Enter number of assignments:\t");
                numbOfGrades = int.Parse(Console.ReadLine());
            }

            string[] assignmentName = new string[numbOfGrades+1];
            double[] assignmentGrade = new double[numbOfGrades+1];

            for (int i = 1; i <= numbOfGrades; i++)
            {
                Console.Write("\nEnter assignment name:\t\t\t");
                assignmentName[i] = Console.ReadLine();
                Console.Write("Enter assignment grade:\t\t\t");
                assignmentGrade[i] = double.Parse(Console.ReadLine());

                while(assignmentGrade[i] < 0 || assignmentGrade[i] > 100)
                {
                    Console.WriteLine("This is an invalid grade. Please enter a grade " +
                        "between 0 and 100.\t");
                    assignmentGrade[i] = double.Parse(Console.ReadLine());
                }
            }


            // PART 2 - Grade Record

            Console.WriteLine("\nGrade Report:");

            for(int i = 1; i <= numbOfGrades; i++)
            {
                Console.WriteLine(assignmentName[i] + ": " + assignmentGrade[i]);
            }

            double sum = 0;
            for (int i = 0; i < assignmentGrade.Length; i++)
            {
                sum += assignmentGrade[i];
            }

            double avgGrade = sum / numbOfGrades;

            Console.WriteLine("-----------------------------");
            Console.WriteLine("Final Average:\t" + avgGrade);
            Console.WriteLine("-----------------------------\n\n");

            // PART 3

            Console.Write("Which index would you like to replace?  ");
            int userInput = int.Parse(Console.ReadLine());
            while (userInput < 1 || userInput > numbOfGrades)
            {
                Console.Write("Index must be It must be a number " +
                    "between 1 and {0}.  ", numbOfGrades);
            }
            Console.WriteLine("\nWhat is the new grade?");
            double newGrade = double.Parse(Console.ReadLine());
            
            assignmentGrade[userInput] = newGrade;
            while (newGrade < 0 || newGrade > 100)
            {
                Console.Write("This is invalid. Must be between 0 and 100.  ");
                assignmentGrade[userInput] = newGrade;
            }
            

            // PART 4

            for (int i = 1; i <= numbOfGrades; i++)
            {
                Console.WriteLine(assignmentName[i] + ": " + assignmentGrade[i]);
            }

            double sum2 = 0;
            for (int i = 0; i < assignmentGrade.Length; i++)
            {
                sum2 += assignmentGrade[i];
            }

            double avgGrade2 = sum2 / numbOfGrades;

            Console.WriteLine("-----------------------------");
            Console.WriteLine("Final Average:\t" + avgGrade2);
            Console.WriteLine("-----------------------------\n\n");

        }
        
        

    }


}
